Toggle Directional Light: L
Move Light Left/Right: Move Mouse
Move Light Forward/Back: Mouse Wheel

The custom item is the diamond.

Material used on moon: Green Plastic (http://devernay.free.fr/cours/opengl/materials.html)

